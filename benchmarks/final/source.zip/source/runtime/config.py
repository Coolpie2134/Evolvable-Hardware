from __future__ import annotations

from dataclasses import dataclass
import os

from substrates.nervous.pulse import PulseConfig
from .escape import EscapeConfig
from .limits import MAX_CHROMOSOME_COUNT
from .mutation import DEFAULT_MUTATION_LIMIT, DEFAULT_STAGNATION_BETA

DEFAULT_MAX_TELOMERE = 20
DEFAULT_NERVOUS_MAX_TELOMERE = 24
DEFAULT_LUT_MAX_TELOMERE = 18
# FNV Max telomere is the ceiling on an ARM's lifespan - how many placements one
# branch may make before it dies - and never a growth radius. A genome has two
# arms per chromosome, so this bounds the body directly.
DEFAULT_FNV_MAX_TELOMERE = 32
MAX_EVALUATION_WORKERS = 16
# Physical cores are usually the useful ceiling for these CPU-heavy event
# simulations. There is no portable stdlib physical-core count, so default to
# at most eight processes and leave two logical CPUs for Tk/Windows.
DEFAULT_EVALUATION_WORKERS = max(
    1, min((os.cpu_count() or 2) - 2, 8))
FNV_FAMILIES = (
    'LOGIC', 'DELAY', 'NORMALIZER', 'HOLD', 'C_ELEMENT', 'TOGGLE',
    'GATED_OSCILLATOR',
)
LUT_FUNCTION_FAMILIES = (
    'ROUTING', 'AND', 'OR', 'XOR', 'VETO', 'THRESHOLD', 'MUX',
    'UNRESTRICTED',
)

# Empirical fresh-run defaults. LUT/FNV benefited from sustained structural
# exploration, while that same hot search damaged SNN timing lineages and did
# not improve the Nervous substrate. See results/ga_validate_*_*.json.
_BASELINE_GA_TUNING = {
    'mean_mutations': 4.0,
    'immigrant_fraction': 0.08,
    'tournament_size': 4,
    'elite_count': 5,
    'mutation_decay': 0.997,
    'stagnation_beta': 1.0,
}
_EXPLORATORY_GA_TUNING = {
    'mean_mutations': 2.0,
    'immigrant_fraction': 0.12,
    'tournament_size': 3,
    'elite_count': 3,
    'mutation_decay': 1.0,
    'stagnation_beta': 2.0,
}


def default_ga_tuning(backend):
    """Return independent, mutable fresh-run tuning for ``backend``."""
    source = (_EXPLORATORY_GA_TUNING
              if str(backend).lower() in ('fnv', 'lut')
              else _BASELINE_GA_TUNING)
    return dict(source)

# Supported Nervous run and checkpoint profile:
# (tile architecture, physics model, retired delay-vector toggle).
NV_NEW_RUN_PROFILES = {
    'analog_tri': ('tri3', 'paper_analog', None),
}


def is_current_nv_profile(ga_config):
    profile = (ga_config.tile_arch, ga_config.node_model,
               ga_config.evolve_delay)
    return profile in NV_NEW_RUN_PROFILES.values()


def validate_new_nv_profile(ga_config):
    """Reject removed NV profiles at execution and checkpoint-load boundaries."""
    if not is_current_nv_profile(ga_config):
        raise ValueError(
            'new nervous-net runs use the analog tri-circuit profile '
            "(tile_arch='tri3', node_model='paper_analog'); the single-tile "
            'and digital tri-circuit engines are retired')


def nv_run_config(**ga):
    """Assemble the supported analog tri-circuit profile."""
    arch, model, evolve_delay = NV_NEW_RUN_PROFILES['analog_tri']
    ga.setdefault('tile_arch', arch)
    ga.setdefault('node_model', model)
    ga.setdefault('evolve_delay', evolve_delay)
    # The live tri-tile Full Adder's balanced two-arm partition is 23/21 tiles.
    # Twenty made that valid body impossible before fitness was consulted.
    ga.setdefault('max_telomere', DEFAULT_NERVOUS_MAX_TELOMERE)
    return RunConfig(ga=GAConfig(**ga), pulse=PulseConfig(model=model))


def default_max_telomere(backend):
    """Backend-specific growth ceiling used by fresh GUI runs."""
    name = str(backend).lower()
    if name == 'lut':
        return DEFAULT_LUT_MAX_TELOMERE
    if name == 'fnv':
        return DEFAULT_FNV_MAX_TELOMERE
    if name == 'nervous':
        return DEFAULT_NERVOUS_MAX_TELOMERE
    return DEFAULT_MAX_TELOMERE


@dataclass(frozen=True)
class GAConfig:
    mean_mutations: float = 4.0
    mutation_limit: float = DEFAULT_MUTATION_LIMIT
    immigrant_fraction: float = 0.08
    tournament_size: int = 4
    elite_count: int = 1
    mutation_decay: float = 0.997
    stagnation_beta: float = DEFAULT_STAGNATION_BETA
    selection: str = 'tournament'
    # When false, selected parents are cloned separately and then mutated;
    # crossover is skipped without turning mutation or immigration off.
    recombination_enabled: bool = True
    # Analog physics is the only runnable Nervous engine. The tile field is
    # shared by backend-neutral configs; nv_run_config() supplies tri3 for NV.
    node_model: str = 'paper_analog'
    tile_arch: str = 'single'
    # Compatibility I/O binding strategy
    # (substrates/nervous/io_placement.py IO_STRATEGIES).
    # Fresh Nervous/FNV runs require 'fixed' because their native genomes carry
    # evolved source layouts and use fitted probes. SNN supports every legacy
    # strategy except directional terminal nodes; LUT keeps the legacy
    # strategies programmatically in addition to its two native lut_io_mode
    # choices.
    #   'fixed'          - compatibility selector. SNN uses declared pads;
    #                      Nervous/FNV genomes resolve native layouts; LUT uses
    #                      its selected native lut_io_mode.
    #   'terminal_nodes' - body genes evolve ordinary/input/output identity;
    #                      matching mature cells become one-way terminals.
    #   'tag_rank'       - body-gene expression tags rank mature cells; ports
    #                      claim the highest still-free cells in order (Method A).
    #   'wiring_chromosome' - chromosome 3 is a non-developmental but evolvable
    #                      port map. Each gene selects one cell by node type and
    #                      offset in an unbiased stable site order (Method B).
    #   'spatial_chromosome' - chromosome 3 evolves one normalised (x,y)
    #                      anchor per port. Input anchors are developmental
    #                      germlines; outputs attach to nearest free live cells.
    # Kept 'fixed' by default so native-pad backends and old fixed checkpoints
    # are unambiguous; the literal is duplicated from IO_STRATEGIES to keep
    # runtime backend-neutral (no substrates.nervous import at module level).
    io_placement: str = 'fixed'
    # LUT-only physical input architecture. Source pads are ordinary developed
    # cells made source-only at runtime; exterior edges are fixed alternating
    # logical-input buses whose taps face inward through one directional input
    # of every perimeter LUT face.
    lut_io_mode: str = 'source_pads'
    # LUT-only physical truth-table inventory. Named banks contain concrete
    # 16-bit tables; UNRESTRICTED is the historical all-65,536-table substrate.
    # The tuple is a run-level hardware selection, never a per-node parameter.
    lut_function_families: tuple[str, ...] = ('UNRESTRICTED',)
    # Delay-mutation toggle, decoupled from the model name for ablations.
    # ``None`` keeps the model's pairing (pulse_delay <-> delay mutation). An
    # explicit False disables it - node_model='pulse_delay' with
    # evolve_delay=False is width-preserving transport at the FIXED base delay,
    # isolating width preservation from delay evolvability. True is only valid
    # under the matching model: the engine ignores the vector everywhere else,
    # so enabling the mutation there would silently evolve dead genes.
    # (A companion evolve_width toggle existed until width evolution was
    # retired from the substrate; old checkpoints carrying it are migrated.)
    evolve_delay: bool | None = None
    max_telomere: int = DEFAULT_MAX_TELOMERE
    # ``None`` keeps the legacy/direct-API behaviour where chromosome count may
    # evolve. GUI runs set this explicitly: the "Chroms" option is a structural
    # constraint, not merely an initial-population hint.
    chromosome_count: int | None = None
    cache_size: int = 200_000
    # One process per independently evaluated genome. Keeping this in the run
    # config makes GUI and benchmark load comparable and prevents a default run
    # from saturating every logical CPU on a desktop machine.
    evaluation_workers: int = DEFAULT_EVALUATION_WORKERS
    # Useful for an interactive solver bank, but not part of measuring whether
    # a target was solved. Benchmarks disable this extra post-solve search.
    diversify_solvers: bool = True
    # Local-minimum escape mechanisms (runtime/escape.py). Every one is off by
    # default, so an unconfigured run - and any checkpoint written before the
    # module existed - behaves exactly as it did before.
    escape: EscapeConfig = EscapeConfig()

    def __post_init__(self):
        if self.mean_mutations < 0:
            raise ValueError('mean_mutations must be non-negative')
        if self.mutation_limit < 1:
            raise ValueError('mutation_limit must be at least 1')
        if not 0 <= self.immigrant_fraction <= 1:
            raise ValueError('immigrant_fraction must be between 0 and 1')
        if self.tournament_size < 1 or self.elite_count < 0:
            raise ValueError('tournament_size must be positive and elite_count non-negative')
        if not 0 < self.mutation_decay <= 1:
            raise ValueError('mutation_decay must be in (0, 1]')
        if not 0 <= self.stagnation_beta <= 10:
            raise ValueError('stagnation_beta must be between 0 and 10')
        if self.selection not in ('tournament', 'lexicase'):
            raise ValueError('selection must be tournament or lexicase')
        if self.node_model not in ('uniform', 'pulse_delay', 'paper_analog'):
            raise ValueError('node_model must be uniform, pulse_delay or '
                             'paper_analog')
        if self.tile_arch not in ('single', 'tri3'):
            raise ValueError("tile_arch must be 'single' or 'tri3'")
        if self.io_placement not in (
                'fixed', 'terminal_nodes', 'tag_rank', 'wiring_chromosome',
                'spatial_chromosome'):
            raise ValueError(
                "io_placement must be 'fixed', 'terminal_nodes', 'tag_rank', "
                "'wiring_chromosome' or 'spatial_chromosome'")
        if self.lut_io_mode not in ('source_pads', 'exterior_edges'):
            raise ValueError(
                "lut_io_mode must be 'source_pads' or 'exterior_edges'")
        lut_families = tuple(
            str(family).upper() for family in self.lut_function_families)
        unknown_lut_families = set(lut_families).difference(
            LUT_FUNCTION_FAMILIES)
        if unknown_lut_families:
            raise ValueError(
                'unknown LUT function families: %s' %
                ', '.join(sorted(unknown_lut_families)))
        if not lut_families:
            raise ValueError(
                'at least one LUT function family must be enabled')
        if len(set(lut_families)) != len(lut_families):
            raise ValueError('LUT function families may not be repeated')
        object.__setattr__(
            self, 'lut_function_families',
            tuple(family for family in LUT_FUNCTION_FAMILIES
                  if family in lut_families))
        # tri3 evolves routing only, so it pairs with the routing-only engines:
        # 'uniform' (digital) or 'paper_analog' (analog). The width/delay vectors
        # are single-tile node-type features and have no tri3 meaning.
        if self.tile_arch == 'tri3' and self.node_model not in ('uniform',
                                                                'paper_analog'):
            raise ValueError("tri3 tile_arch supports node_model 'uniform' or "
                             "'paper_analog' (width/delay vectors are "
                             'single-tile features)')
        for name, model in (('evolve_delay', 'pulse_delay'),):
            value = getattr(self, name)
            if value is not None and not isinstance(value, bool):
                raise ValueError('%s must be None (model pairing) or boolean' % name)
            if value is True and self.node_model != model:
                raise ValueError(
                    "%s=True requires node_model='%s' (the mutated vector is "
                    'ignored under every other model)' % (name, model))
        if not isinstance(self.recombination_enabled, bool):
            raise ValueError('recombination_enabled must be boolean')
        if self.max_telomere < 1 or self.cache_size < 1:
            raise ValueError('max_telomere and cache_size must be positive')
        if not 1 <= self.evaluation_workers <= MAX_EVALUATION_WORKERS:
            raise ValueError('evaluation_workers must be between 1 and %d' %
                             MAX_EVALUATION_WORKERS)
        if not isinstance(self.diversify_solvers, bool):
            raise ValueError('diversify_solvers must be boolean')
        if (self.chromosome_count is not None
                and not 1 <= self.chromosome_count <= MAX_CHROMOSOME_COUNT):
            raise ValueError('chromosome_count must be between 1 and %d' %
                             MAX_CHROMOSOME_COUNT)
        if not isinstance(self.escape, EscapeConfig):
            raise ValueError('escape must be an EscapeConfig')

    def timing_mutations(self):
        """Resolved ``evolve_delay`` boolean for the GA.

        ``None`` falls back to the node model's pairing, so existing configs
        and checkpoints keep today's behaviour unchanged."""
        return (self.node_model == 'pulse_delay'
                if self.evolve_delay is None else self.evolve_delay)

    @classmethod
    def from_dict(cls, values):
        values = dict(values or {})
        # Width evolution has been retired from the substrate. Old checkpoints
        # still carry its toggle; drop it rather than fail to load.
        values.pop('evolve_width', None)
        # The wiring-chromosome strategy briefly shipped under another name;
        # migrate on load so those checkpoints keep working.
        if values.get('io_placement') == 'sex_chromosome':
            values['io_placement'] = 'wiring_chromosome'
        if 'lut_function_families' in values:
            values['lut_function_families'] = tuple(
                values['lut_function_families'])
        # dataclasses.asdict flattens the nested escape config to a plain dict;
        # rebuild it (tolerantly, so a checkpoint from a different revision of
        # the mechanism set still loads with the rest of its run intact).
        escape = values.get('escape')
        if escape is not None and not isinstance(escape, EscapeConfig):
            values['escape'] = EscapeConfig.from_dict(escape)
        elif escape is None:
            values.pop('escape', None)
        return cls(**values)


@dataclass(frozen=True)
class FNVConfig:
    """Component-bank and output-readout selection for Functional NV Net."""

    families: tuple[str, ...] = FNV_FAMILIES
    # ``fitted`` is the control mode: development is output-rooted but scoring
    # may select the best mature probes. ``genetic`` reads the role sites named
    # by the output chromosome, with an unwritten site remaining silent.
    readout_mode: str = 'genetic'

    def __post_init__(self):
        families = tuple(str(family).upper() for family in self.families)
        unknown = set(families).difference(FNV_FAMILIES)
        if unknown:
            raise ValueError(
                'unknown FNV component families: %s' %
                ', '.join(sorted(unknown)))
        if not families:
            raise ValueError('at least one FNV component family must be enabled')
        if len(set(families)) != len(families):
            raise ValueError('FNV component families may not be repeated')
        object.__setattr__(
            self, 'families',
            tuple(family for family in FNV_FAMILIES if family in families))
        mode = str(self.readout_mode).lower()
        if mode not in ('fitted', 'genetic'):
            raise ValueError("FNV readout_mode must be 'fitted' or 'genetic'")
        object.__setattr__(self, 'readout_mode', mode)

    @classmethod
    def from_dict(cls, values):
        # A fresh FNV run uses its evolved output chromosome.  Checkpoints from
        # before the readout field existed were evaluated with fitted probes,
        # however, so absence during deserialisation must preserve that meaning
        # instead of silently changing their phenotype.
        values = dict(values or {})
        values.setdefault('readout_mode', 'fitted')
        if 'families' in values:
            values['families'] = tuple(values['families'])
        return cls(**values)


@dataclass(frozen=True)
class RunConfig:
    ga: GAConfig = GAConfig()
    pulse: PulseConfig = PulseConfig()
    fnv: FNVConfig = FNVConfig()

    def __post_init__(self):
        if self.ga.node_model != self.pulse.model:
            raise ValueError('ga.node_model must match pulse.model')

    @classmethod
    def from_dict(cls, values):
        values = values or {}
        pulse_values = dict(values.get('pulse', {}))
        # Development-era pulse-delay checkpoints carried a width-to-delay Gain.
        # Delay is now an evolved genome vector, so discard that obsolete global
        # coupling while retaining the base delay and other run physics.
        pulse_values.pop('delay_gain', None)
        ga_values = dict(values.get('ga') or {})
        ga_values.pop('evaluation_chunk_multiplier', None)
        # Older checkpoints stored the timing model only with pulse physics.
        # Promote that value so loading a delay-evolving run cannot quietly
        # disable its mutation operator.
        model = pulse_values.get('model', ga_values.get('node_model', 'paper_analog'))
        # Width evolution is retired: a checkpoint saved under it is loaded on
        # the paper's fixed-width node instead. The genome's dormant width
        # vector is dropped on load (see checkpoint.genome_from_dict), and the
        # GUI flags the run as retired physics because 'uniform'+'single' is
        # not one of NV_NEW_RUN_PROFILES.
        if model == 'evolved_width':
            model = 'uniform'
            pulse_values['model'] = 'uniform'
        ga_values['node_model'] = model
        pulse_values.setdefault('model', model)
        return cls(ga=GAConfig.from_dict(ga_values),
                   pulse=PulseConfig(**pulse_values),
                   fnv=FNVConfig.from_dict(values.get('fnv')))
